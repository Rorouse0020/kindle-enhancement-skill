# Kindle 全栈增强包（kindle-modding-stack v1.0.0）

把一台 Kindle 做成：**越狱 + KOReader + SimpleUI + 微信读书 + Wi-Fi 无线传书 + AI/投资资讯 RSS + 随机睡眠壁纸**。

> 本包在 **Kindle Paperwhite 3（2015）/ 固件 5.16.2.1.1 / soft-float** 上逐项实机验证。
> 其他机型可用同一套流程框架，但**越狱方法、KOReader 安装包、插件版本**需按 `references/01-jailbreak.md` 的判定表重新选择。

---

## 这是什么

| 你会得到 | 说明 |
|---|---|
| 越狱 | WinterBreak2；含**GitHub 被墙时的本地执行变体**（本包核心经验） |
| 阅读器 | KOReader v2026.07.1（soft-float 包）+ 书库路径修正 |
| 界面 | SimpleUI（平铺书架 / 资讯 / AI 划词）+ 微信读书插件 |
| 传书 | 电脑一句命令 Wi-Fi 直传，SHA-256 回读收据；**AZW3/MOBI 自动转 EPUB** |
| 内容 | 资讯 RSS（117 个精编源、**英文保持原文**）+ 24 个英文 RSS（News downloader） |
| 体验 | 15 张睡眠壁纸（名画/文字卡），随机切换 |
| 安全 | 全流程备份点 + 一键体检 + 逐项回滚 + 完整撤销越狱 |

---

## 快速开始

```bash
# 0) 先读主入口（含适用性判定与安全规则）
$EDITOR SKILL.md

# 1) 体检当前设备（只读）
bash scripts/verify-setup.sh /Volumes/Kindle

# 2) 按顺序执行：
#    references/01-jailbreak.md     越狱
#    references/02-koreader.md      KOReader
#    references/03-plugins.md       SimpleUI / 微信读书
#    references/04-send2kindle.md   无线传书 + 格式转换
#    references/05-content-rss.md   资讯 + 英文 RSS
#    references/06-wallpapers.md    睡眠壁纸

# 3) 收尾体检，全绿即复刻成功
bash scripts/verify-setup.sh /Volumes/Kindle
```

---

## 目录结构

```
kindle-modding-stack/
├── SKILL.md                  # 主入口：阶段化流程、决策树、验收清单（先读这个）
├── README.md                 # 本文件（人读的快速开始 / 分发说明）
├── manifest.json             # 元数据（版本、验证环境、文件清单）
├── CHANGELOG.md
├── references/
│   ├── 01-jailbreak.md       # 越狱全流程 + 本地执行变体 + 验证
│   ├── 02-koreader.md        # 包选择、安装、启动器、书库路径修正
│   ├── 03-plugins.md         # SimpleUI / 微信读书 / SSH 插件
│   ├── 04-send2kindle.md     # 安装、配对、信任、格式转换补丁、排障
│   ├── 05-content-rss.md     # 资讯机制、原文优先补丁、源整理、英文 RSS
│   ├── 06-wallpapers.md      # 睡眠屏保机制、素材规格、生成与安装
│   ├── 07-troubleshooting.md # T1–T12 实机故障：症状/根因/命令/修复
│   ├── 08-rollback.md        # 逐项回滚、撤销越狱、修砖、数据恢复
│   └── 09-credits.md         # 第三方组件、许可证、免责声明
├── scripts/
│   ├── verify-setup.sh           # 一键体检（只读）
│   ├── kindle-prepare-local.sh   # 越狱准备（本地 jb.sh + dialoger + 填盘）
│   ├── kindle-ssh.py             # 用配对身份在设备执行命令
│   ├── kindle-push.py            # 递归推送文件到设备
│   ├── apply-rss-curation.py     # 应用资讯源整理
│   ├── apply-wallpapers.py       # 推送壁纸 + 配置屏保
│   └── gen-wallpapers.py         # 生成壁纸素材（公版画/NASA/文字卡）
└── assets/
    ├── dialoger-local.html       # 本地执行版 dialoger（替代官方 GitHub 拉取）
    ├── KOReader.sh               # 设备端启动器 scriptlet
    ├── feed_config.lua           # 24 个已验证英文 RSS
    └── qiaomu_sources.curated.json  # 117 启用的资讯源目录
```

---

## 前置条件

| 项 | 要求 |
|---|---|
| 电脑 | macOS / Linux（脚本以 macOS 为主；Windows 建议 WSL） |
| Python | ≥3.10（send2kindle 运行时） |
| 工具 | `curl`、`unzip`、`rsync`（可选） |
| 硬件 | 能传数据的 USB 线；设备与电脑同一 Wi-Fi |
| 心态 | 越狱有变砖/失保修风险；先读 SKILL.md §2 安全规则 |

---

## 分发给同事

1. 直接给对方这个目录的 **zip**（`kindle-modding-stack-v1.0.0.zip`）。
2. 告诉对方：**先读 `SKILL.md` 的 §1 适用性判定**，机型/固件不匹配就不要照抄命令。
3. 对方在自己的电脑上执行 `bash scripts/verify-setup.sh /Volumes/Kindle` 自检。
4. 若对方使用 Claude Code / Codex 等支持 agent-skills 的工具，把整个目录放进
   `~/.claude/skills/kindle-modding-stack/`（或对应工具的 skills 目录）即可被自动发现；
   纯手工使用者按 README 顺序读文档执行即可。

---

## 已知限制

- KOReader **不支持 AZW3/KFX**；本包用"自动转 EPUB"解决，DRM 文件无法处理。
- 睡眠壁纸**只在 KOReader 内睡眠**生效；原生睡眠屏不动（需 NiLuJe hack，本机固件不建议）。
- 未注册设备：KOReader/传书/资讯可用；商店、KU、官方 Send to Kindle、云同步不可用。
- 第三方服务与 URL 会变；执行前以官方页面为准。

---

## 许可

- 文档 CC-BY-4.0；本包脚本 MIT。
- 第三方组件（KOReader AGPL-3.0、SimpleUI GPL-3.0、KindleUnpack GPL-3.0 等）遵循各自许可证，
  详见 `references/09-credits.md`。本包不重新分发这些组件。

---

## 路径与环境变量（保证换机器可用）

脚本**不含任何本机绝对路径**，按下表解析：

| 变量/参数 | 默认值 | 说明 |
|---|---|---|
| `QIAOMU_SKILL_DIR` | 依次尝试 `~/.claude/skills/qiaomu-send2kindle`、`~/skills/qiaomu-send2kindle`、`~/DeepSeek Harness/Kindle/skills/...` | `kindle-ssh.py` / `kindle-push.py` 靠它找到 send2kindle 的凭据模块 |
| `JB_SH` | `<包>/assets/jb.sh` | 离线时指定已下载的官方 jb.sh |
| `SKIP_HASH=1` | 关 | 跳过 jb.sh 的 sha256 校验（上游更新后用，风险自负） |
| 第 1 个参数 | `/Volumes/Kindle` | 设备挂载点（Linux 常见 `/media/$USER/Kindle`） |
| `--images <dir>` | `<包>/wallpapers/sleep` | `apply-wallpapers.py` 的壁纸来源 |

示例（新机器首次使用）：
```bash
export QIAOMU_SKILL_DIR=~/skills/qiaomu-send2kindle
bash scripts/verify-setup.sh /Volumes/Kindle
python3 scripts/kindle-ssh.py 'date'                 # 设备时间（T1 体检）
python3 scripts/apply-rss-curation.py /Volumes/Kindle
python3 scripts/gen-wallpapers.py                    # 生成壁纸到 <包>/wallpapers/sleep
python3 scripts/apply-wallpapers.py /Volumes/Kindle
```

> `jb.sh` 不随包分发（8.7 MB 第三方文件）；`kindle-prepare-local.sh` 会自动下载并校验
> `cfe16df16effaa3be04dcddc63b542db57b6146820936d4098f8326d58fbbc02`（v2.4.0）。
